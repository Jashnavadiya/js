


window.addEventListener('load',()=>{
    setTimeout(()=>{document.querySelector('.main-loader').style.display="none";},1000)
})