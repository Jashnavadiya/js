

"https://colorlib.com/wp/free-fashion-website-templates/"
"https://dribbble.com/shots/21727513-Furniture-store-UI-design-Product-Page"