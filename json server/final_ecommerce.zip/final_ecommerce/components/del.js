const DelData=(url)=>{
fetch(url,{
    method:"DELETE"
})
}
export default DelData